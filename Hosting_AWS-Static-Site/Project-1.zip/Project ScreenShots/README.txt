
---------Deploy Static Website on AWS For Udacity Cloud Devops Engineer -------------

In this project I have deploy a static website to AWS using S3, CloudFront, and IAM.


Link to the web site: 

http://dm8cc4d0keypx.cloudfront.net/index.html



Please see the attached Screenshots for steps taken in setting up this static web site on A.W.S.

--------------The files included on A.W.S S3 bucket are: ------------------

index.html - The Index document for the website.

/img - The background image file for the website.

/vendor - Bootssrap CSS framework, Font, and JavaScript libraries needed for the website to function.

/css - CSS files for the website.


